const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');

function getColorHex(colorName) {
	const isHexCode = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(colorName);
	if (isHexCode) {
		return colorName;
	}
	return null;
}

module.exports = {
	data: new SlashCommandBuilder()
		.setName('intro')
		.setDescription('Membuat sebuah perkenalan yang sudah diembed dan dikirim secara otomatis')
		.addStringOption(option =>
			option.setName('name')
				.setDescription('Siapakah Namamu?')
				.setRequired(true))
		.addStringOption(option =>
			option.setName('description')
				.setDescription('ada kata kata perkenalan? contoh: salken')
				.setRequired(true))
		.addStringOption(option =>
			option.setName('hobby')
				.setDescription('Apa Hobimu?')
				.setRequired(false))
		.addStringOption(option =>
			option.setName('color')
				.setDescription('Mengganti warna garis embed menggunakan kode hex')
				.setRequired(false))
		.addStringOption(option =>
			option.setName('location')
				.setDescription('Dari mana kamu?')
				.setRequired(false)),
	async execute(interaction) {
		await interaction.deferReply();
		const user = interaction.user;
		const filename = `avatar.${user.avatar?.startsWith('a_') ? 'gif' : 'png'}`;
		const avatar = new AttachmentBuilder(user.displayAvatarURL(), { name: filename });
		const name = interaction.options.getString('name');
		const hobby = interaction.options.getString('hobby') || '-';
		const location = interaction.options.getString('location') || '-';
		const description = interaction.options.getString('description');
		const colorInput = interaction.options.getString('color') || '#0099ff';
		const color = getColorHex(colorInput);
		if (!color) {
			await interaction.reply({ content: 'Warna tidak valid. Pastikan Anda menggunakan [kode hex](https://www.google.com/search?q=Pemilih+warna) yang valid.', ephemeral: true });
			return;
		}

		const introEmbed = new EmbedBuilder()
			.setColor(color)
			.setTitle('Perkenalkan')
			.setThumbnail(`attachment://${filename}`)
			.setDescription(`Nama: ${name}\nHobi: ${hobby}\nDaerah asal: ${location}\n\n${description}`);

		await interaction.editReply({ embeds: [introEmbed], files: [avatar] });
	},
};